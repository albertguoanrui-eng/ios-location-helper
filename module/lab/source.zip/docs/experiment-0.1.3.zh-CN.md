# 0.1.3 手机实验步骤

这是原项目的独立实验版本，仍只使用 Shadowrocket，不需要付费签名、电脑连接或新 App。**目前没有 iOS 27 RC 定位成功的真机证据。** 这是排除规则、引擎和存储问题的实验，不是已经验证的绕过系统限制方案。

## 已完成的工作

- 规则与运行时同时支持 HTTPS 默认显式端口 `:443` 和 HTTP `:80`，拒绝非默认端口和相似恶意域名。旧规则确实漏掉显式端口；尚不知道手机脚本收到的 URL 是否包含端口，故不能称为已确认根因。
- 三个适配脚本指定 `engine=jsc`。这是引擎兼容性实验，不能改变 iOS 对 TLS 证书的信任策略。
- 初始化和执行异常不再全部静默：单独记录 `entered` / `completed` / `failed`。记录只含时间、版本、脚本类别和异常类型；存储不可用时尝试输出固定日志标记，不输出异常正文、坐标或请求数据。整个脚本的语法解析失败或未被小火箭调度，仍可能没有记录。
- 中国区域名的人工自检与 WLOC 使用同一个请求适配脚本，验证持久化读写，以及合成二进制数据能否改成伦敦坐标。自检独立于用户设置和真实请求记录。它不验证系统定位客户端的 TLS 信任，也不验证真实响应钩子已触发。
- `module/` 中旧版保持原字节，实验包在 `module/lab/`。构建会检查旧版文件没有被覆盖。

## 只操作一次的验证流程

1. 打开小火箭，在当前配置的模块列表**停用旧定位助手**，以及其他定位改写模块。保留已有代理配置。
2. 在模块列表添加下面的 URL，下载后确认出现“定位助手 · 0.1.3 实验版 CDN”，并启用。

   ```text
   https://cdn.jsdelivr.net/gh/albertguoanrui-eng/ios-location-helper@main/module/lab/location-helper-cdn-0.1.3.sgmodule
   ```

   CDN 下载失败时用原始入口，两者只选一个：

   ```text
   https://raw.githubusercontent.com/albertguoanrui-eng/ios-location-helper/main/module/lab/location-helper-0.1.3.sgmodule
   ```

3. 保持已经安装并完全信任的小火箭证书。开启 HTTPS 解密；本次沿用之前测试的 HTTP/2 解密关闭状态，避免同时改变更多变量。解密域名仍为原来的五个，没有新增通配域名：

   ```text
   gs-loc.apple.com,gs-loc-cn.apple.com,gsp-ssl.ls.apple.com,bluedot.is.autonavi.com,bluedot.is.autonavi.com.gds.alibabadns.com
   ```

4. 保存配置，重新连接一次小火箭。Safari 打开：

   ```text
   https://gs-loc.apple.com/wloc-helper/?v=0.1.3
   ```

5. 确认右上角为 **0.1.3**。页面下方点击“运行本机自检”。出现“本机实验自检”页面后，观察 `storage` 与 `binaryRewrite` 是否都是 `true`。这个页面会保留结果，不用手动粘贴脚本。
6. 点击“返回面板并刷新诊断”。填入伦敦纬度 `51.5074`、经度 `-0.1278`、精度 `25`，点击一次“保存并开启改写”。旧坐标会沿用，显式保存用于开始这次独立的请求记录。
7. 打开苹果地图，点击定位箭头，等待约 30 秒；观察真实蓝点，搜索结果或地图视角移到伦敦不算成功。
8. 返回面板，点击“刷新诊断”，再点击“复制诊断”。返回完整 JSON，并说明地图是在伦敦、真实位置，还是无法定位。自检记录在 `state.experiments.probe`；脚本运行记录在 `state.experiments.runtime`。

不需要再次重装证书、反复重启或反复保存同一坐标。如果步骤 5 自检页面打不开，直接报告这一结果；不要把官网 404 当作自检结果。

## 如何解释结果

| 结果 | 能确认什么 | 仍不能确认什么 |
| --- | --- | --- |
| 自检页面打开，两个值 true | Safari 到中国区域名的人工请求可进入脚本；读写和合成数据改写通过 | 系统定位客户端是否接受解密证书，真实响应钩子是否触发 |
| storage false | 本次存储往返或记录写入未通过 | 系统是否阻止定位请求 |
| binaryRewrite false | 当前引擎中的合成改写未通过 | 是否为系统定位接口变化 |
| runtime 中 observe/wloc 为 failed | 定位路径进入了请求脚本，但执行发生异常 | 异常具体原因需结合类型和脚本日志 |
| 自检通过、真实 request/response 都为 null | 人工路径可用，真实定位路径仍没有有效观测记录 | 不能仅凭此断言证书固定；也可能是规则、调度、缓存或请求方式变化 |
| response 为 patched，蓝点仍是真实位置 | 某次匹配响应被改写 | 系统是否使用该结果；脚本无法认证调用者一定是 locationd |

`runtime` 是当前版本各类脚本最近一次运行记录，不随保存坐标清零；以时间戳和 `source` 区分。`panel/control` 在生成页面快照时可能仍为 `entered`，因为返回内容之前完成记录尚未写入，这是正常现象。真实请求、响应仍按当前坐标设置的 revision 隔离。`systemLocationVerified` 不会自动变为 true。

## 本地验证与边界

```sh
npm test
npm run build:github
python3 scripts/check-jsc.py
npm run check
```

32 项 Node 测试通过；Linux 上已安装的 JavaScriptCore 也执行实际构建出的三个脚本，覆盖保存、显式端口、人工自检隔离、伦敦负经度二进制响应改写和写入故障记录。Shadowrocket API 使用模拟实现。这不是 iOS 真机 TLS / GPS 测试，也不能证明手机使用了所指定的引擎。

本次没有改变原上游二进制编解码器；新增匹配、运行边界和设备实验逻辑由本项目实现。HTTP 请求脚本只有进入 HTTP 阶段后才能执行；若连接在 TLS 阶段结束，增加响应代码或生成测试坐标都不能证明已绕过这一阶段。之前日志只证明存在解密尝试和很快结束的连接，未包含足以确认根因的 TLS 错误。

## 回退

停用实验模块，启用原 0.1.2；二者共享原坐标设置。要停止改写，在可打开的面板点击“停止改写”并停用定位模块。已存在的系统定位缓存不能由本面板直接清除。

本项目发布目标为 GitHub 模块下载，没有配置 Jenkins 任务。
